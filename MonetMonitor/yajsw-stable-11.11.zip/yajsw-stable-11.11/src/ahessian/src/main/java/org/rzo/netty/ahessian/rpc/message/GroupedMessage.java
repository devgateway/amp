package org.rzo.netty.ahessian.rpc.message;

public interface GroupedMessage
{
	public Integer getGroup();

}
