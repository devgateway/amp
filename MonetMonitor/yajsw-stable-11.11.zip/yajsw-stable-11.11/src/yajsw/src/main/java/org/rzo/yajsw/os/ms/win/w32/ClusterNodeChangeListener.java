package org.rzo.yajsw.os.ms.win.w32;

public interface ClusterNodeChangeListener
{
	public void nodeChanged();

}
