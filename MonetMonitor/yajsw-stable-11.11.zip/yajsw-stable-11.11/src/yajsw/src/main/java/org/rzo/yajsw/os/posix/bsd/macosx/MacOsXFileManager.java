package org.rzo.yajsw.os.posix.bsd.macosx;

import org.rzo.yajsw.os.posix.PosixFileManager;

public class MacOsXFileManager extends PosixFileManager
{

}
