package org.rzo.yajsw.os.posix.linux;

import org.rzo.yajsw.os.posix.PosixKeyboard;

public class LinuxKeyboard extends PosixKeyboard
{

}
