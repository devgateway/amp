//>>built
define("esri/Credential",["dojo/_base/declare","dojo/has","esri/kernel","esri/IdentityManagerBase"],function(a,b,c,d){a=a(d.Credential,{});b("extend-esri")&&(c.Credential=a);return a});
//@ sourceMappingURL=Credential.js.map