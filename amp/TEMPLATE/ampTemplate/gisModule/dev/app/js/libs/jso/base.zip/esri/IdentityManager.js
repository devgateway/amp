//>>built
define("esri/IdentityManager",["esri/kernel","esri/IdentityManagerDialog"],function(a,b){a.id=new b;return a.id});
//@ sourceMappingURL=IdentityManager.js.map