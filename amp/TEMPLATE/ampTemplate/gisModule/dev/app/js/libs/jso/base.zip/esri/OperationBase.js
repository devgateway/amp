//>>built
define("esri/OperationBase",["dojo/_base/declare","dojo/has","esri/kernel"],function(a,b,c){a=a(null,{declaredClass:"esri.OperationBase",type:"not implemented",label:"not implemented",constructor:function(a){a=a||{};a.label&&(this.label=a.label)},performUndo:function(){},performRedo:function(){}});b("extend-esri")&&(c.OperationBase=a);return a});
//@ sourceMappingURL=OperationBase.js.map