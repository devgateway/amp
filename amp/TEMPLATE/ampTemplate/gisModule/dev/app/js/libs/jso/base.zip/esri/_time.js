//>>built
define("esri/_time",["esri/TimeExtent"],function(){return{}});
//@ sourceMappingURL=_time.js.map