//>>built
define("esri/dijit/AttributeInspector-all",["esri/layers/FeatureLayer","esri/dijit/AttributeInspector"],function(a,b){return{}});
//@ sourceMappingURL=AttributeInspector-all.js.map