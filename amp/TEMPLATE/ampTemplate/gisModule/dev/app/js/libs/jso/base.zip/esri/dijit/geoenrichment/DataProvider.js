//>>built
define("esri/dijit/geoenrichment/DataProvider",["../../declare","dojo/Evented"],function(a,b){return a([b],{metadata:null,constructor:function(){this.metadata={name:"StdGeographyName",address:"address"}},getData:function(){throw new "Not implemented";}})});
//@ sourceMappingURL=DataProvider.js.map