//>>built
define("esri/dijit/geoenrichment/InfographicsOptionsItem",[],function(){return function(a,b){this.type=a;this.variables=b;this.index=this.title=null;this.isVisible=!0}});
//@ sourceMappingURL=InfographicsOptionsItem.js.map