//>>built
define("esri/dijit/geoenrichment/themes/light/AgePyramid",{color:"#666666",theme:{axis:{stroke:{color:"#666666"},tick:{color:"#666666",fontColor:"#666666"}}},female:{fill:"#f279ca"},line:{fill:"#F7F7F7",stroke:{color:"#666666"}},highlight:"#CECECE"});
//@ sourceMappingURL=AgePyramid.js.map