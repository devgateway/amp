//>>built
define("esri/geometry/ScreenPoint",["dojo/_base/declare","dojo/_base/lang","dojo/has","esri/kernel","esri/geometry/Point"],function(a,b,c,d,e){a=a(e,{declaredClass:"esri.geometry.ScreenPoint",verifySR:function(){}});c("extend-esri")&&b.setObject("geometry.ScreenPoint",a,d);return a});
//@ sourceMappingURL=ScreenPoint.js.map