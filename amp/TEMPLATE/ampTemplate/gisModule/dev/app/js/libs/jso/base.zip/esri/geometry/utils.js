//>>built
define("esri/geometry/utils",["esri/geometry/Polygon","esri/geometry/geodesicUtils","esri/geometry/normalizeUtils"],function(){return{}});
//@ sourceMappingURL=utils.js.map