//>>built
define("esri/layers/DataSource",["dojo/_base/declare","dojo/_base/lang","dojo/has","esri/kernel"],function(a,b,c,d){a=a(null,{declaredClass:"esri.layers.DataSource",constructor:function(a){a&&b.mixin(this,a)},toJson:function(){}});c("extend-esri")&&b.setObject("layers.DataSource",a,d);return a});
//@ sourceMappingURL=DataSource.js.map