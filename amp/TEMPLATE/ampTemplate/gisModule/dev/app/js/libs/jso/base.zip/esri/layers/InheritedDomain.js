//>>built
define("esri/layers/InheritedDomain",["dojo/_base/declare","dojo/_base/lang","dojo/has","esri/kernel","esri/layers/Domain"],function(a,b,c,d,e){a=a([e],{declaredClass:"esri.layers.InheritedDomain"});c("extend-esri")&&b.setObject("layers.InheritedDomain",a,d);return a});
//@ sourceMappingURL=InheritedDomain.js.map