//>>built
define("esri/layers/LayerSource",["dojo/_base/declare","dojo/_base/lang","dojo/has","esri/kernel"],function(a,b,c,d){a=a(null,{declaredClass:"esri.layers.LayerSource",type:null,constructor:function(a){a&&b.mixin(this,a)},toJson:function(){}});c("extend-esri")&&b.setObject("layers.LayerSource",a,d);return a});
//@ sourceMappingURL=LayerSource.js.map