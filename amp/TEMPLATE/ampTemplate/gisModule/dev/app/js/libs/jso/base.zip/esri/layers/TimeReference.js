//>>built
define("esri/layers/TimeReference",["dojo/_base/declare","dojo/_base/lang","dojo/has","esri/kernel"],function(a,b,c,d){a=a(null,{declaredClass:"esri.layers.TimeReference",constructor:function(a){a&&b.mixin(this,a)}});c("extend-esri")&&b.setObject("layers.TimeReference",a,d);return a});
//@ sourceMappingURL=TimeReference.js.map