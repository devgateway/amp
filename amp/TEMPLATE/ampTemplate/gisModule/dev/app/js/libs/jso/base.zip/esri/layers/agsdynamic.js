//>>built
define("esri/layers/agsdynamic",["esri/layers/agscommon","esri/layers/ArcGISDynamicMapServiceLayer","esri/_time"],function(){return{}});
//@ sourceMappingURL=agsdynamic.js.map