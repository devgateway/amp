//>>built
define("esri/layers/agsimageservice","esri/layers/agscommon esri/layers/ArcGISImageServiceLayer esri/layers/ImageServiceParameters esri/layers/MosaicRule esri/layers/RasterFunction esri/utils".split(" "),function(){return{}});
//@ sourceMappingURL=agsimageservice.js.map