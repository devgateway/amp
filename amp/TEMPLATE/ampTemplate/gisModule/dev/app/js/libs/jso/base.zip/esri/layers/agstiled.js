//>>built
define("esri/layers/agstiled",["esri/layers/agscommon","esri/layers/ArcGISTiledMapServiceLayer"],function(){return{}});
//@ sourceMappingURL=agstiled.js.map