//>>built
define("esri/layers/dynamic",["esri/geometry","esri/layers/DynamicMapServiceLayer"],function(){return{}});
//@ sourceMappingURL=dynamic.js.map