//>>built
define("esri/layers/graphics",["esri/layers/GraphicsLayer","esri/graphic","esri/renderer"],function(){return{}});
//@ sourceMappingURL=graphics.js.map