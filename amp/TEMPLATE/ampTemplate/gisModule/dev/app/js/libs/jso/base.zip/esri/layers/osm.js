//>>built
define("esri/layers/osm",["esri/layers/OpenStreetMapLayer"],function(){return{}});
//@ sourceMappingURL=osm.js.map