//>>built
define("esri/layers/tiled",["esri/layers/TiledMapServiceLayer","esri/layers/TileInfo","esri/layers/LOD","esri/geometry","esri/utils"],function(){return{}});
//@ sourceMappingURL=tiled.js.map