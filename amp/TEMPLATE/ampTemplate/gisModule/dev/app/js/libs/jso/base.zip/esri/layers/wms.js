//>>built
define("esri/layers/wms",["esri/layers/agscommon","esri/layers/dynamic","esri/layers/WMSLayer"],function(){return{}});
//@ sourceMappingURL=wms.js.map