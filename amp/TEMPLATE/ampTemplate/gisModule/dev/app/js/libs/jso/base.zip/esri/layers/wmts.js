//>>built
define("esri/layers/wmts",["esri/layers/agscommon","esri/layers/tiled","esri/layers/WMTSLayer"],function(){return{}});
//@ sourceMappingURL=wmts.js.map