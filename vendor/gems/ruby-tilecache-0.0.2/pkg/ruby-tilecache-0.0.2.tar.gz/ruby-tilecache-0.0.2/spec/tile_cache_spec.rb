# $Id$

require File.join(File.dirname(__FILE__), %w[spec_helper])

describe TileCache do
end

# EOF
